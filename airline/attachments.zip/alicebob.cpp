#include "airline.h"
#include <bits/stdc++.h>
using namespace std;

///poor man's communication problem
///do not include any global variables, use only local variables and namespaced global variables.
///If you wish to use 'global' variables, use the namespace for alice and bob, and do not let alice read bob's variables and vice versa

namespace alice{
	///put all "global" variables for alice inside here
	int aliceU = 3;
	int aliceV = 2;
};

void Alice( int N, int M, int A[], int B[] ){
	using namespace alice;
	
	InitG(aliceU, aliceV);
	MakeG(0, 1, 2);
	MakeG(1, 1, 3);
}

namespace bob{
	///put all "global" variables for bob inside here
};

void Bob( int U, int V, int C[], int D[] ){
	using namespace bob;
	
	InitMap(3, 2);
	MakeMap(1, 2);
	MakeMap(1, 3);
}


