void Alice( int N, int M, int A[], int B[] );
void InitG( int V, int U );
void MakeG( int pos, int C, int D );
void Bob( int V, int U, int C[], int D[] );
void InitMap( int N, int M );
void MakeMap( int A, int B );
